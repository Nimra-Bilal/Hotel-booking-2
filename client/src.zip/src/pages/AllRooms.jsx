// import React, { useState } from 'react'
// import { assets, facilityIcons, roomsDummyData } from '../Assets/assets/assets';
// import { useNavigate } from 'react-router-dom';
// import StarRating from '../components/StarRating';


// const checkBox = ({label , selected = false , onChange = () => {

// }}) =>{
//     return (
//         <label className='flex gap-3 items-center cursor-pointer  mt-2 text-sm '>
//             <input type="checkbox" checked={selected} 
//             onChange ={ (e)=>onChange(e.target.checked , label ) }name="" id="" />

// <span className='font-light select-none'>{label}</span>

//         </label>
//     )
// }


// const radioButton = ({label , selected=false , onChange = ()=>{}})=>{
//  return (
//         <label className='flex gap-3 items-center cursor-pointer  mt-2 text-sm '>
//             <input type="radio" name="sortOption" checked={selected} 
//             onChange ={ ()=>onChange( label ) } />

// <span className='font-light select-none'>{label}</span>

//         </label>
//     )
// }

// const AllRooms = () => {
//     const navigate = useNavigate();
//     const [openFilters , setOpenFilters] = useState(false);
//     const roomTypes = [
// "Single Bed" , 
// "Double Bed" , 
// "Luxury Room ", "Family Suite"
// ];

// const PriceRanges = [
//     '0 to 500',
//     '500 to 1000',
//     '1000 to 2000',
//     '2000 to 3000'
// ];

// const sortOptions = [
// 'Price low to high ',
// 'Price High to Low ',
// 'Newest First'
// ];


//   return (
    
//     <div >
//       <h1>All Rooms</h1>


//       <div className='flex flex-col-reverse 
//     lg:flex-row items-start justify-between pt-28 
//     md:pt-35 px-4 md:px-16 lg:px-24 xl:px-32'>
// <div className='flex flex-col items-start text-left'>
//     <h1 className='font-playfair text-4xl md:text-[40px]'>
// Hotel Rooms:
//     </h1>
//     <p className='text-sm md:text-base text-gray-500/90 mt-2 max-w-174'>
//         Take advantage of our limited time offers and special
//          packages to enhance your stay and create unforgettable memories.
//     </p>

// {roomsDummyData.map((room)=>(
//     <div key={room._id} className='flex flex-col md:flex-row items-start py-10 gap-6 border-b border-gray-300 last:pb-30 lg:border-0'>
//         <img onClick={()=>{navigate(`/rooms/${room._id}`); scrollTo(0,0)}} src={room.images[0]} title='View Room Details' 
//         className='max-h-65 md:w-1/2 rounded-xl shadow-lg object-cover cursor-pointer' alt="hotel-rooms" />
//    <div>
//     <p onClick={()=>{navigate(`/rooms/${room._id}`); scrollTo(0,0)}} className='text-gray-500'> {room.hotel.city} </p>
//     <p className='text-gray-800 text-3xl font-playfair cursor-pointer'> {room.hotel.name}</p>
//     <div className='flex items-center '> 
//         <StarRating/>
//         <p className='ml-2'>200+ Views</p>
//     </div>
//     <div className='flex items-center gap-1 text-gray-500 mt-2 text-sm'>
// <img src={assets.locationIcon} alt="locationIcon" />
// <span>{room.hotel.address}</span>
//     </div>

// {/* room amenities */}
//     <div className='flex flex-wrap items-center mt-3 mb-6 gap-4 '>
// {room.amenities.map((item,index)=>(
//     <div className='flex items-center gap-2 px-3 py-2 rounded-lg bg-[#F5F5FF]/70' key={index} >
//         <img className='w-5 h-5 ' src={facilityIcons[item]} alt="" />
//     <p className='text-xs'>{item}</p>
//     </div>
// ))}


//     </div>

// {/* room price per night  */}
// <p className='text-xl font-medium text-gray-700 '>
//     ${room.pricePerNight}/night
// </p>



//    </div>
//     </div>
// ))}


// </div> 
// {/* filters */}
//       <div className='bg-white w-80 border border-gray-300 text-gray-600 max-lg:mb-8 min-lg:mt-16'>

// <div className={`flex items-center justify-between px-5 py-2.5 min-lg:border-b border-gray-300 ${openFilters && "border-b"}`}>
//     <p className='text-base font-medium text-gray-800'>
// Filters
//     </p>
//     <div className='text-xs cursor-pointer'>
//          <span onClick={()=>setOpenFilters(!openFilters)} className='lg:hidden'> {openFilters ? 'Hide ' : 'show' } </span>
//         <span className='hidden lg:block'>Clear</span>
//     </div>
// </div>

// <div className={`${openFilters ? 'h-auto ' : 'h-0 lg:h-auto '} overflow-hidden transition-all duration-700 `}>
// <div className='px-5 pt-5'>
//     <p className='text-gray-800 font-medium pb-2 '>
//         Popular Filters
//     </p>
//     {
//         roomTypes.map((room , index)=>(
//             <checkBox key={index} label={room} />
//         ))
//     }
// </div>

// <div className='px-5 pt-5'>
//     <p className='text-gray-800 font-medium pb-2 '>
//         Price Range
//     </p>
//     {
//         PriceRanges.map((range , index)=>(
//             <checkBox key={index} label={`$ ${range}`} />
//         ))
//     }
// </div>


// <div className='px-5 pt-5'>
//     <p className='text-gray-800 font-medium pb-2 '>
//         Sort By
//     </p>
//     {
//         sortOptions.map((option , index)=>(
//             <radioButton key={index} label={option} />
//         ))
//     }
// </div>


// </div>


//       </div>
//       </div>
     
//     </div>
//   )
// }

// export default AllRooms;





// import React, { useState } from 'react'
// import { assets, facilityIcons, roomsDummyData } from '../Assets/assets/assets';
// import { useNavigate } from 'react-router-dom';
// import StarRating from '../components/StarRating';

// // Component names should start with capital letters
// const CheckBox = ({ label, selected = false, onChange = () => {} }) => {
//     return (
//         <label className='flex gap-3 items-center cursor-pointer mt-2 text-sm'>
//             <input 
//                 type="checkbox" 
//                 checked={selected} 
//                 onChange={(e) => onChange(e.target.checked, label)}
//             />
//             <span className='font-light select-none'>{label}</span>
//         </label>
//     );
// };

// // Component names should start with capital letters
// const RadioButton = ({ label, selected = false, onChange = () => {} }) => {
//     return (
//         <label className='flex gap-3 items-center cursor-pointer mt-2 text-sm'>
//             <input 
//                 type="radio" 
//                 name="sortOption" 
//                 checked={selected}
//                 onChange={() => onChange(label)}
//             />
//             <span className='font-light select-none'>{label}</span>
//         </label>
//     );
// };

// const AllRooms = () => {
//     const navigate = useNavigate();
//     const [openFilters, setOpenFilters] = useState(false);
    
//     // State for filters
//     const [selectedRoomTypes, setSelectedRoomTypes] = useState([]);
//     const [selectedPriceRanges, setSelectedPriceRanges] = useState([]);
//     const [selectedSortOption, setSelectedSortOption] = useState('');
    
//     const roomTypes = [
//         "Single Bed", 
//         "Double Bed", 
//         "Luxury Room", 
//         "Family Suite"
//     ];

//     const priceRanges = [
//         '0 to 500',
//         '500 to 1000',
//         '1000 to 2000',
//         '2000 to 3000'
//     ];

//     const sortOptions = [
//         'Price low to high',
//         'Price High to Low',
//         'Newest First'
//     ];

//     const handleRoomTypeChange = (checked, label) => {
//         if (checked) {
//             setSelectedRoomTypes([...selectedRoomTypes, label]);
//         } else {
//             setSelectedRoomTypes(selectedRoomTypes.filter(type => type !== label));
//         }
//     };

//     const handlePriceRangeChange = (checked, label) => {
//         if (checked) {
//             setSelectedPriceRanges([...selectedPriceRanges, label]);
//         } else {
//             setSelectedPriceRanges(selectedPriceRanges.filter(range => range !== label));
//         }
//     };

//     const handleSortOptionChange = (label) => {
//         setSelectedSortOption(label);
//     };

//     const handleClearFilters = () => {
//         setSelectedRoomTypes([]);
//         setSelectedPriceRanges([]);
//         setSelectedSortOption('');
//     };

//     return (
//         <div className='pt-24'>
//             <div className='flex flex-col-reverse lg:flex-row items-start justify-between px-4 md:px-16 lg:px-24 xl:px-32'>
//                 <div className='flex flex-col items-start text-left w-full lg:w-2/3'>
//                     <h1 className='font-playfair text-4xl md:text-[40px]'>
//                         Hotel Rooms
//                     </h1>
//                     <p className='text-sm md:text-base text-gray-500/90 mt-2 max-w-3xl'>
//                         Take advantage of our limited time offers and special
//                         packages to enhance your stay and create unforgettable memories.
//                     </p>

//                     {roomsDummyData.map((room) => (
//                         <div key={room._id} className='flex flex-col md:flex-row items-start py-10 gap-6 border-b border-gray-300 last:border-b-0 w-full'>
//                             <img 
//                                 onClick={() => { 
//                                     navigate(`/rooms/${room._id}`); 
//                                     window.scrollTo(0, 0); 
//                                 }} 
//                                 src={room.images[0]} 
//                                 title='View Room Details'
//                                 className='w-full md:w-1/2 h-64 md:h-80 rounded-xl shadow-lg object-cover cursor-pointer' 
//                                 alt="hotel-rooms" 
//                             />
//                             <div className='w-full md:w-1/2'>
//                                 <p 
//                                     onClick={() => { 
//                                         navigate(`/rooms/${room._id}`); 
//                                         window.scrollTo(0, 0); 
//                                     }} 
//                                     className='text-gray-500 cursor-pointer'
//                                 >
//                                     {room.hotel.city}
//                                 </p>
//                                 <p 
//                                     className='text-gray-800 text-3xl font-playfair cursor-pointer'
//                                     onClick={() => { 
//                                         navigate(`/rooms/${room._id}`); 
//                                         window.scrollTo(0, 0); 
//                                     }}
//                                 >
//                                     {room.hotel.name}
//                                 </p>
//                                 <div className='flex items-center'> 
//                                     <StarRating rating={room.rating || 0} />
//                                     <p className='ml-2'>{room.views || 0}+ Views</p>
//                                 </div>
//                                 <div className='flex items-center gap-1 text-gray-500 mt-2 text-sm'>
//                                     <img src={assets.locationIcon} alt="locationIcon" className='w-4 h-4' />
//                                     <span>{room.hotel.address}</span>
//                                 </div>

//                                 {/* Room amenities */}
//                                 <div className='flex flex-wrap items-center mt-3 mb-6 gap-2'>
//                                     {room.amenities.map((item, index) => (
//                                         <div className='flex items-center gap-2 px-3 py-2 rounded-lg bg-[#F5F5FF]/70' key={index}>
//                                             <img className='w-5 h-5' src={facilityIcons[item]} alt={item} />
//                                             <p className='text-xs'>{item}</p>
//                                         </div>
//                                     ))}
//                                 </div>

//                                 {/* Room price per night */}
//                                 <p className='text-xl font-medium text-gray-700'>
//                                     ${room.pricePerNight}/night
//                                 </p>
//                             </div>
//                         </div>
//                     ))}
//                 </div>
                
//                 {/* Filters Sidebar */}
//                 <div className='bg-white w-full lg:w-80 border border-gray-300 text-gray-600 mb-8 lg:mb-0 lg:ml-8 lg:sticky lg:top-24'>
//                     <div className={`flex items-center justify-between px-5 py-2.5 border-b border-gray-300`}>
//                         <p className='text-base font-medium text-gray-800'>
//                             Filters
//                         </p>
//                         <div className='text-xs cursor-pointer flex gap-2'>
//                             <span 
//                                 onClick={() => setOpenFilters(!openFilters)} 
//                                 className='lg:hidden cursor-pointer text-blue-600'
//                             >
//                                 {openFilters ? 'Hide' : 'Show'}
//                             </span>
//                             <span 
//                                 onClick={handleClearFilters}
//                                 className='cursor-pointer text-blue-600'
//                             >
//                                 Clear
//                             </span>
//                         </div>
//                     </div>

//                     <div className={`${openFilters ? 'block' : 'hidden lg:block'}`}>
//                         <div className='px-5 pt-5'>
//                             <p className='text-gray-800 font-medium pb-2'>
//                                 Popular Filters
//                             </p>
//                             {roomTypes.map((room, index) => (
//                                 <CheckBox 
//                                     key={index} 
//                                     label={room}
//                                     selected={selectedRoomTypes.includes(room)}
//                                     onChange={handleRoomTypeChange}
//                                 />
//                             ))}
//                         </div>

//                         <div className='px-5 pt-5'>
//                             <p className='text-gray-800 font-medium pb-2'>
//                                 Price Range
//                             </p>
//                             {priceRanges.map((range, index) => (
//                                 <CheckBox 
//                                     key={index} 
//                                     label={`$ ${range}`}
//                                     selected={selectedPriceRanges.includes(range)}
//                                     onChange={handlePriceRangeChange}
//                                 />
//                             ))}
//                         </div>

//                         <div className='px-5 pt-5 pb-5'>
//                             <p className='text-gray-800 font-medium pb-2'>
//                                 Sort By
//                             </p>
//                             {sortOptions.map((option, index) => (
//                                 <RadioButton 
//                                     key={index} 
//                                     label={option}
//                                     selected={selectedSortOption === option}
//                                     onChange={handleSortOptionChange}
//                                 />
//                             ))}
//                         </div>
//                     </div>
//                 </div>
//             </div>
//         </div>
//     );
// };

// export default AllRooms;



import React, { useState } from 'react'
import { assets, facilityIcons, roomsDummyData } from '../Assets/assets/assets';
import { useNavigate } from 'react-router-dom';
import StarRating from '../components/StarRating';

// Component names should start with capital letters
const CheckBox = ({ label, selected = false, onChange = () => {} }) => {
    return (
        <label className='flex gap-3 items-center cursor-pointer mt-2 text-sm'>
            <input 
                type="checkbox" 
                checked={selected} 
                onChange={(e) => onChange(e.target.checked, label)}
            />
            <span className='font-light select-none'>{label}</span>
        </label>
    );
};

// Component names should start with capital letters
const RadioButton = ({ label, selected = false, onChange = () => {} }) => {
    return (
        <label className='flex gap-3 items-center cursor-pointer mt-2 text-sm'>
            <input 
                type="radio" 
                name="sortOption" 
                checked={selected}
                onChange={() => onChange(label)}
            />
            <span className='font-light select-none'>{label}</span>
        </label>
    );
};

const AllRooms = () => {
    const navigate = useNavigate();
    const [openFilters, setOpenFilters] = useState(false);
    
    // State for filters
    const [selectedRoomTypes, setSelectedRoomTypes] = useState([]);
    const [selectedPriceRanges, setSelectedPriceRanges] = useState([]);
    const [selectedSortOption, setSelectedSortOption] = useState('');
    
    const roomTypes = [
        "Single Bed", 
        "Double Bed", 
        "Luxury Room", 
        "Family Suite"
    ];

    const priceRanges = [
        '0 to 500',
        '500 to 1000',
        '1000 to 2000',
        '2000 to 3000'
    ];

    const sortOptions = [
        'Price low to high',
        'Price High to Low',
        'Newest First'
    ];

    const handleRoomTypeChange = (checked, label) => {
        if (checked) {
            setSelectedRoomTypes([...selectedRoomTypes, label]);
        } else {
            setSelectedRoomTypes(selectedRoomTypes.filter(type => type !== label));
        }
    };

    const handlePriceRangeChange = (checked, label) => {
        if (checked) {
            setSelectedPriceRanges([...selectedPriceRanges, label]);
        } else {
            setSelectedPriceRanges(selectedPriceRanges.filter(range => range !== label));
        }
    };

    const handleSortOptionChange = (label) => {
        setSelectedSortOption(label);
    };

    const handleClearFilters = () => {
        setSelectedRoomTypes([]);
        setSelectedPriceRanges([]);
        setSelectedSortOption('');
    };

    return (
        <div className='pt-24'>
            <div className='flex flex-col-reverse lg:flex-row items-start justify-between px-4 md:px-16 lg:px-24 xl:px-32'>
                <div className='flex flex-col items-start text-left w-full lg:w-2/3'>
                    <h1 className='font-playfair text-4xl md:text-[40px]'>
                        Hotel Rooms
                    </h1>
                    <p className='text-sm md:text-base text-gray-500/90 mt-2 max-w-3xl'>
                        Take advantage of our limited time offers and special
                        packages to enhance your stay and create unforgettable memories.
                    </p>

                    {roomsDummyData.map((room) => (
                        <div key={room._id} className='flex flex-col md:flex-row items-start py-10 gap-6 border-b border-gray-300 last:border-b-0 w-full'>
                            <img 
                                onClick={() => { 
                                    navigate(`/rooms/${room._id}`); 
                                    window.scrollTo(0, 0); 
                                }} 
                                src={room.images[0]} 
                                title='View Room Details'
                                className='w-full md:w-1/2 h-64 md:h-80 rounded-xl shadow-lg object-cover cursor-pointer' 
                                alt="hotel-rooms" 
                            />
                            <div className='w-full md:w-1/2'>
                                <p 
                                    onClick={() => { 
                                        navigate(`/rooms/${room._id}`); 
                                        window.scrollTo(0, 0); 
                                    }} 
                                    className='text-gray-500 cursor-pointer'
                                >
                                    {room.hotel.city}
                                </p>
                                <p 
                                    className='text-gray-800 text-3xl font-playfair cursor-pointer'
                                    onClick={() => { 
                                        navigate(`/rooms/${room._id}`); 
                                        window.scrollTo(0, 0); 
                                    }}
                                >
                                    {room.hotel.name}
                                </p>
                                <div className='flex items-center'> 
                                    <StarRating />
                                    <p className='ml-2'>200+ Views</p>
                                </div>
                                <div className='flex items-center gap-1 text-gray-500 mt-2 text-sm'>
                                    <img src={assets.locationIcon} alt="locationIcon" className='w-4 h-4' />
                                    <span>{room.hotel.address}</span>
                                </div>

                                {/* Room amenities */}
                                <div className='flex flex-wrap items-center mt-3 mb-6 gap-2'>
                                    {room.amenities.map((item, index) => (
                                        <div className='flex items-center gap-2 px-3 py-2 rounded-lg bg-[#F5F5FF]/70' key={index}>
                                            <img className='w-5 h-5' src={facilityIcons[item]} alt={item} />
                                            <p className='text-xs'>{item}</p>
                                        </div>
                                    ))}
                                </div>

                                {/* Room price per night */}
                                <p className='text-xl font-medium text-gray-700'>
                                    ${room.pricePerNight}/night
                                </p>
                            </div>
                        </div>
                    ))}
                </div>
                
                {/* Filters Sidebar */}
                <div className='bg-white w-full lg:w-80 border border-gray-300 text-gray-600 mb-8 lg:mb-8 lg:ml-8  lg:top-24'>
                    <div className='flex items-center justify-between px-5 py-2.5 border-b border-gray-300'>
                        <p className='text-base font-medium text-gray-800'>
                            Filters
                        </p>
                        <div className='text-xs cursor-pointer flex gap-2'>
                            <span 
                                onClick={() => setOpenFilters(!openFilters)} 
                                className='lg:hidden cursor-pointer text-blue-600'
                            >
                                {openFilters ? 'Hide' : 'Show'}
                            </span>
                            <span 
                                onClick={handleClearFilters}
                                className='cursor-pointer text-blue-600'
                            >
                                Clear
                            </span>
                        </div>
                    </div>

                    <div className={openFilters ? 'block' : 'hidden lg:block'}>
                        <div className='px-5 pt-5'>
                            <p className='text-gray-800 font-medium pb-2'>
                                Popular Filters
                            </p>
                            {roomTypes.map((room, index) => (
                                <CheckBox 
                                    key={index} 
                                    label={room}
                                    selected={selectedRoomTypes.includes(room)}
                                    onChange={handleRoomTypeChange}
                                />
                            ))}
                        </div>

                        <div className='px-5 pt-5'>
                            <p className='text-gray-800 font-medium pb-2'>
                                Price Range
                            </p>
                            {priceRanges.map((range, index) => (
                                <CheckBox 
                                    key={index} 
                                    label={`$${range}`}
                                    selected={selectedPriceRanges.includes(range)}
                                    onChange={handlePriceRangeChange}
                                />
                            ))}
                        </div>

                        <div className='px-5 pt-5 pb-7'>
                            <p className='text-gray-800 font-medium pb-2'>
                                Sort By
                            </p>
                            {sortOptions.map((option, index) => (
                                <RadioButton 
                                    key={index} 
                                    label={option}
                                    selected={selectedSortOption === option}
                                    onChange={handleSortOptionChange}
                                />
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AllRooms;
